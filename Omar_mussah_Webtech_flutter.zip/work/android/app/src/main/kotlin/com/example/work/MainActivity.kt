package com.example.work

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
