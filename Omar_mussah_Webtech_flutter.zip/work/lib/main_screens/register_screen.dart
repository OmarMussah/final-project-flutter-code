import 'package:flutter/material.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({Key? key}) : super(key: key);

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  String studentID = '';
  String name = '';
  String email = '';
  // String password = "";
  String dateOfBirth = '';
  String yearGroup = '';
  String major = '';
  String hasCampusResidence = "";
  String bestFood = '';
  String bestMovie = "";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.red,
      body: Stack(
        children: [
          Center(
            child: SizedBox(
              width: MediaQuery.of(context).size.width * .5,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Image.asset('images/download.jpg'),
                  TextField(
                    onChanged: (value) {
                      studentID = value;
                    },
                    style: const TextStyle(fontSize: 16, color: Colors.white),
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.deepPurpleAccent,
                          width: 2,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.deepPurpleAccent,
                          width: 2,
                        ),
                      ),
                      hintText: 'ID',
                      hintStyle: TextStyle(color: Colors.white),
                      // icon: Icon(
                      //   Icons.email,
                      //   color: Colors.white,
                      // )
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  // TextField(
                  //   onChanged: (value) {
                  //     password = value;
                  //   },
                  //   obscureText: true,
                  //   style: const TextStyle(fontSize: 16, color: Colors.white),
                  //   decoration: const InputDecoration(
                  //     enabledBorder: OutlineInputBorder(
                  //       borderSide: BorderSide(
                  //         color: Colors.deepPurpleAccent,
                  //         width: 2,
                  //       ),
                  //     ),
                  //     focusedBorder: OutlineInputBorder(
                  //       borderSide: BorderSide(
                  //         color: Colors.deepPurpleAccent,
                  //         width: 2,
                  //       ),
                  //     ),
                  //     hintText: 'password',
                  //     hintStyle: TextStyle(color: Colors.white),
                  //     // icon: Icon(
                  //     //   Icons.lock,
                  //     //   color: Colors.white,
                  //     // )
                  //   ),
                  // ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextField(
                    onChanged: (value) {
                      name = value;
                    },
                    style: const TextStyle(fontSize: 16, color: Colors.white),
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.deepPurpleAccent,
                          width: 2,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.deepPurpleAccent,
                          width: 2,
                        ),
                      ),
                      hintText: 'name',
                      hintStyle: TextStyle(color: Colors.white),
                      // icon: Icon(
                      //   Icons.lock,
                      //   color: Colors.white,
                      // )
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),

                  TextField(
                    onChanged: (value) {
                      email = value;
                    },
                    style: const TextStyle(fontSize: 16, color: Colors.white),
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.deepPurpleAccent,
                          width: 2,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.deepPurpleAccent,
                          width: 2,
                        ),
                      ),
                      hintText: 'email',
                      hintStyle: TextStyle(color: Colors.white),
                      // icon: Icon(
                      //   Icons.lock,
                      //   color: Colors.white,
                      // )
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),

                  TextField(
                    onChanged: (value) {
                      dateOfBirth = value;
                    },
                    style: const TextStyle(fontSize: 16, color: Colors.white),
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.deepPurpleAccent,
                          width: 2,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.deepPurpleAccent,
                          width: 2,
                        ),
                      ),
                      hintText: 'dateOfBirth',
                      hintStyle: TextStyle(color: Colors.white),
                      // icon: Icon(
                      //   Icons.lock,
                      //   color: Colors.white,
                      // )
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),

                  TextField(
                    onChanged: (value) {
                      yearGroup = value;
                    },
                    style: const TextStyle(fontSize: 16, color: Colors.white),
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.deepPurpleAccent,
                          width: 2,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.deepPurpleAccent,
                          width: 2,
                        ),
                      ),
                      hintText: 'yearGroup',
                      hintStyle: TextStyle(color: Colors.white),
                      // icon: Icon(
                      //   Icons.lock,
                      //   color: Colors.white,
                      // )
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),

                  TextField(
                    onChanged: (value) {
                      major = value;
                    },
                    style: const TextStyle(fontSize: 16, color: Colors.white),
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.deepPurpleAccent,
                          width: 2,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.deepPurpleAccent,
                          width: 2,
                        ),
                      ),
                      hintText: 'major',
                      hintStyle: TextStyle(color: Colors.white),
                      // icon: Icon(
                      //   Icons.lock,
                      //   color: Colors.white,
                      // )
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextField(
                    onChanged: (value) {
                      hasCampusResidence = value;
                    },
                    style: const TextStyle(fontSize: 16, color: Colors.white),
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.deepPurpleAccent,
                          width: 2,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.deepPurpleAccent,
                          width: 2,
                        ),
                      ),
                      hintText: 'Campus Residence',
                      hintStyle: TextStyle(color: Colors.white),
                      // icon: Icon(
                      //   Icons.lock,
                      //   color: Colors.white,
                      // )
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextField(
                    onChanged: (value) {
                      bestFood = value;
                    },
                    style: const TextStyle(fontSize: 16, color: Colors.white),
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.deepPurpleAccent,
                          width: 2,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.deepPurpleAccent,
                          width: 2,
                        ),
                      ),
                      hintText: 'best food',
                      hintStyle: TextStyle(color: Colors.white),
                      // icon: Icon(
                      //   Icons.lock,
                      //   color: Colors.white,
                      // )
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextField(
                    onChanged: (value) {
                      bestMovie = value;
                    },
                    style: const TextStyle(fontSize: 16, color: Colors.white),
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.deepPurpleAccent,
                          width: 2,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.deepPurpleAccent,
                          width: 2,
                        ),
                      ),
                      hintText: 'best movie',
                      hintStyle: TextStyle(color: Colors.white),
                      // icon: Icon(
                      //   Icons.lock,
                      //   color: Colors.white,
                      // )
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  // Register button
                  ElevatedButton(
                    onPressed: () {},
                    child: const Text('Register'),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  // Login link
                  GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: const Text(
                      'Already have an account? Login',
                      style: TextStyle(
                        color: Colors.white,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
