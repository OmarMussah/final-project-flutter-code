import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:work/main_screens/create_post.dart';

class Post {
  final String author;
  final String content;
  final String timestamp;

  Post({required this.author, required this.content, required this.timestamp});

  factory Post.fromJson(Map<String, dynamic> json) {
    return Post(
      author: json['author'],
      content: json['content'],
      timestamp: json['timestamp'],
    );
  }
}

Future<List<Post>> fetchPosts() async {
  final response = await http.get(Uri.parse('http://127.0.0.1:5000/posts'));
  if (response.statusCode == 200) {
    List<dynamic> jsonResponse = jsonDecode(response.body);
    return jsonResponse.map((post) => Post.fromJson(post)).toList();
  } else {
    throw Exception('Failed to load posts');
  }
}

class NewsFeed extends StatelessWidget {
  const NewsFeed({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: const Text('News Feed'),
          actions: [
            Expanded(
              child: Align(
                alignment: Alignment.centerLeft,
                child: PopupMenuButton<String>(
                  onSelected: (value) {
                    if (value == 'Create Post') {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => CreatePostPage()),
                      );
                    }
                  },
                  itemBuilder: (BuildContext context) {
                    return <PopupMenuEntry<String>>[
                      const PopupMenuItem<String>(
                        value: 'Create Post',
                        child: Text('Create Post'),
                      ),
                      const PopupMenuItem<String>(
                        value: 'Profile page',
                        child: Text('View Profile'),
                      ),
                      const PopupMenuItem<String>(
                        value: 'user3',
                        child: Text('User 3'),
                      ),
                    ];
                  },
                ),
              ),
            ),
          ],
        ),
        body: FutureBuilder<List<Post>>(
          future: fetchPosts(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              return ListView.builder(
                itemCount: snapshot.data!.length,
                itemBuilder: (context, index) {
                  return Card(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          snapshot.data![index].author,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          snapshot.data![index].content,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          snapshot.data![index].timestamp,
                          style: const TextStyle(color: Colors.grey),
                        ),
                      ],
                    ),
                  );
                },
              );
            } else if (snapshot.hasError) {
              return Center(
                child: Text("${snapshot.error}"),
              );
            }
            return const Center(child: CircularProgressIndicator());
          },
        ),
      ),
    );
  }
}
